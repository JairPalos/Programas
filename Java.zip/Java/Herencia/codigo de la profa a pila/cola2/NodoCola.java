package cola2;
public class NodoCola{
	int dato;
	NodoCola siguiente;
	//decalrarar el constructor
	public NodoCola(int d){
		dato=d;
		siguiente=null;
	}
}
