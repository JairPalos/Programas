package Viajero;
public class Coordenadas {
    public int x;
    public int y;
    public int clases;
    
    public Coordenadas(){
        this.x=x;
        this.y=y;
        this.clases=clases;
    }
    public void setX(int x){
        this.x=x;
    }
    public int getX(){
        return x;
    }
     public void setY(int y){
        this.y=y;
    }
    public int getY(){
        return y;
    }
    
     public void setClases(int clases){
        this.clases=clases;
    }
    public int getClases(){
        return clases;
    }
   
    
    
}
