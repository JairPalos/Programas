#include <iostream>
float* crea_vect(int);
//void ini_vect(float* ,int);
float* lee_vect(char *,int);
void muestra_vect(float* ,int);
float** crea_mat(int,int);
float** lee_mat(char *,int,int);
void muestra_mat(float**,int,int);
float** mat_trans(float**,int,int);
float vecxvec(float*,float*,int);
