<?php
	
	$mysqli= new mysqli('localhost','root','','Muebleria');
	if($mysqli->connect_error){

		die('error en la base de datos'.$mysqli->connect_error);
	}
?>