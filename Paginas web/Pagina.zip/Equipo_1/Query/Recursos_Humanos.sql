SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


CREATE TABLE `aspirantes` (
  `idAspirante` AUTO_INCREMENT,
  'Nombre' varchar(20),
  'ApPat' varchar(20),
  'ApMat' varchar(20),
  `celular` varchar(20) DEFAULT NULL,
  `profesion` varchar(20) DEFAULT NULL,
  `idVacanteAspira` AUTO_INCREMENT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cargos`
--

CREATE TABLE `cargos` (
  `nombreCargo` varchar(20) DEFAULT NULL,
  `salario` double DEFAULT NULL,
  `responsabilidadPrincipal` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departamentos`
--

CREATE TABLE `departamentos` (
  `nombreDepartamento` varchar(30) DEFAULT NULL,
  `idDepartamento` AUTO_INCREMENT,
  `encargadoZona` varchar(20) DEFAULT NULL,
  `numZona` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleados`
--

CREATE TABLE `empleados` (
  `numEmpleado` AUTO_INCREMENT,
  `nombre` varchar(20) DEFAULT NULL,
  `apPaterno` varchar(30) DEFAULT NULL,
  `apMaterno` varchar(30) DEFAULT NULL,
  `RFC` varchar(30) DEFAULT NULL,
  `NSS` varchar(30) DEFAULT NULL,
  `estado` varchar(29) DEFAULT NULL,
  `municipio` varchar(20) DEFAULT NULL,
  `colonia` varchar(20) DEFAULT NULL,
  `numExt` int(11) DEFAULT NULL,
  `numInt` int(11) DEFAULT NULL,
  `idUsuarioSistema` AUTO_INCREMENT DEFAULT NULL,
  `idDepartamentoUsuario` AUTO_INCREMENT DEFAULT NULL,
  `idCargoUsuario` AUTO_INCREMENT DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

---------------------------------------------------------------

CREATE TABLE 'HorarioEntrada'(

folio AUTO_INCREMENT,
idEmpleado int(11) DEFAULT NULL,
HoraEntrada datetime DEFAULT NULL,

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
------------------------------------------
CREATE TABLE 'HorarioInicioComida'(
folioci AUTO_INCREMENT,
idEmpleado int(11) DEFAULT NULL,
HoraComida datetime DEFAULT NULL,
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4; ENGINE=InnoDB DEFAULT CHARSET=utf8mb4

CREATE TABLE 'HorarioFinComida'(
foliocf AUTO_INCREMENT,
idEmpleado int(11) DEFAULT NULL,
HoraComida datetime DEFAULT NULL,
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4; ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
-------------------------------------
CREATE TABLE 'HorarioSalida'(

folios AUTO_INCREMENT,
idEmpleado int(11) DEFAULT NULL,
HoraSalida datetime DEFAULT NULL,
-----------------------------------------------
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4; ENGINE=InnoDB DEFAULT CHARSET=utf8mb4


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `incapacidades`
--

CREATE TABLE `incapacidades` (
  `idIncapacidad` int(11) NOT NULL,
  `numEmpleadoInc` int(11) DEFAULT NULL,
  `causa` varchar(30) DEFAULT NULL,
  `inicioIncapacidad` datetime DEFAULT NULL,
  `terminoIncapacidad` datetime DEFAULT NULL,
  `salarioApoyo` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sanciones`
--

CREATE TABLE `sanciones` (
  `idSancion` int(11),
  `numEmpleadoSancionado` int(11) DEFAULT NULL,
  `descripcionSancion` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `usuario` varchar(30) DEFAULT NULL,
  `contraseña` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vacantes`
--

CREATE TABLE `vacantes` (
  `idVacante` AUTO_INCREMENT,
  `NombreVacante` varchar(50) DEFAULT NULL,
  `Descripcion` varchar(200) DEFAULT NULL,
  `Sector` varchar(30) DEFAULT NULL,
  `Sueldo` decimal(5,2) DEFAULT NULL,
  `Email` varchar(64) DEFAULT NULL,
  `Horario` varchar(50) DEFAULT NULL,
  `Escolaridad` varchar(50) DEFAULT NULL,
  `Categoria` varchar(60) DEFAULT NULL,
  `Experiencia` varchar(200) DEFAULT NULL,
  `Aptitudes` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
---------------------------------------------------------
CREATE table 'Vacaciones'(
Foliov AUTO_INCREMENT,
idEmpleado int(11) DEFAULT NULL,
FechaInicio datetime DEFAULT NULL,
FechaTermino datetime DEFAULT null,

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

---------------------------------------------------
ALTER TABLE `HorarioEntrada`
  ADD PRIMARY KEY (`folio`),
  ADD KEY `folio` (`folio`);
------------------------------------------------------
ALTER TABLE `HorarioInicioComida`
  ADD PRIMARY KEY (`folioci`),
  ADD KEY `folioc` (`folioc`);

ALTER TABLE `HorarioFinComida`
  ADD PRIMARY KEY (`foliocf`),
  ADD KEY `folioc` (`folioc`);
---------------------------------------------------

ALTER TABLE `HorarioSalida`
  ADD PRIMARY KEY (`folios`),
  ADD KEY `folios` (`folios`);

------------------------------------------------------

ALTER TABLE `Vacaciones`
  ADD PRIMARY KEY (`foliov`),
  ADD KEY `foliov` (`foliov`);
---------------------------------------------------------
-- Indices de la tabla `aspirantes`
--
ALTER TABLE `aspirantes`
  ADD PRIMARY KEY (`idAspirante`),
  ADD KEY `idVacanteAspira` (`idVacanteAspira`);
---------------------------------------------------
--
-- Indices de la tabla `cargos`
-
ALTER TABLE `cargos`
  ADD PRIMARY KEY (`nombreCargo`);

--
-- Indices de la tabla `departamentos`
--
ALTER TABLE `departamentos`
  ADD PRIMARY KEY (`idDepartamento`);

--
-- Indices de la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD PRIMARY KEY (`numEmpleado`),
  ADD KEY `idUsuarioSistema` (`idUsuarioSistema`),
  ADD KEY `idDepartamentoUsuario` (`idDepartamentoUsuario`),
  ADD KEY `idCargoUsuario` (`idCargoUsuario`);

--
-- Indices de la tabla `entradassalidas`
--
ALTER TABLE `entradassalidas`
  ADD PRIMARY KEY (`folio`),
  ADD KEY `numEmpleadoRegistro` (`numEmpleadoRegistro`);

--
-- Indices de la tabla `incapacidades`
--
ALTER TABLE `incapacidades`
  ADD PRIMARY KEY (`idIncapacidad`),
  ADD KEY `numEmpleadoInc` (`numEmpleadoInc`);

--
-- Indices de la tabla `sanciones`
--
ALTER TABLE `sanciones`
  ADD PRIMARY KEY (`idSancion`),
  ADD KEY `numEmpleadoSancionado` (`numEmpleadoSancionado`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`usuario`);

--
-- Indices de la tabla `vacantes`
--
ALTER TABLE `vacantes`
  ADD PRIMARY KEY (`idVacante`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `aspirantes`
--
ALTER TABLE `aspirantes`
  MODIFY `idAspirante` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `idUsuario` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `vacantes`
--
ALTER TABLE `vacantes`
  MODIFY `idVacante` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `aspirantes`
--
ALTER TABLE `aspirantes`
  ADD CONSTRAINT `aspirantes_ibfk_1` FOREIGN KEY (`idVacanteAspira`) REFERENCES `vacantes` (`idVacante`);

--
-- Filtros para la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD CONSTRAINT `empleados_ibfk_1` FOREIGN KEY (`idUsuarioSistema`) REFERENCES `usuarios` (`idUsuario`),
  ADD CONSTRAINT `empleados_ibfk_2` FOREIGN KEY (`idDepartamentoUsuario`) REFERENCES `departamentos` (`idDepartamento`),
  ADD CONSTRAINT `empleados_ibfk_3` FOREIGN KEY (`idCargoUsuario`) REFERENCES `cargos` (`idCargo`);

--
-- Filtros para la tabla `incapacidades`
--
ALTER TABLE `incapacidades`
  ADD CONSTRAINT `incapacidades_ibfk_1` FOREIGN KEY (`numEmpleadoInc`) REFERENCES `empleados` (`numEmpleado`);

--
-- Filtros para la tabla `sanciones`
--
ALTER TABLE `sanciones`
  ADD CONSTRAINT `sanciones_ibfk_1` FOREIGN KEY (`numEmpleadoSancionado`) REFERENCES `empleados` (`numEmpleado`);
COMMIT;
