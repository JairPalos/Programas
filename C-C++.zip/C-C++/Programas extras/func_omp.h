#include <iostream>
float* crea_vect(int);
float* lee_vect(char *, int);
int muestra_vect(float*, int);
void productoVector(char *, char *, int, int);
float** crea_mat(int, int);
float** lee_mat(char *, int, int);
void muestra_mat(float**, int,int);
float vecxvec(float*,float*,int);
void matxVec(const float* ,const float* , float* , int, int);
void matrixVectorMult(double*, double*, double*, int, int);
void productoMatxVec(char *, char *, int, int, int);
float ** mat_trans(float **,int, int);
