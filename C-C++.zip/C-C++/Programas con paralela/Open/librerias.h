#include <iostream>
float* crea_vect(int);
//void ini_vect(float* ,int);
float* lee_vect(char *,int);
void muestra_vect(float* ,int);
