package pila;// paquete de la clase
public class NodoPila{// inicio de la clase nodoCola
	int dato;// se crea una variable para el datos
	NodoPila siguiente;// se crea una variable de nodoCola
	//decalrarar el constructor
	public NodoPila(int d){// se crea el constructor
		dato=d;// el dato lo para a la variable datos
		siguiente=null;//la variable siguiente lo limpia
	}// fin del constructor
}// sin de la clase
