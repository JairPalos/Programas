CREATE DATABASE Muebleria;
use muebleria;

CREATE TABLE Empleado(		
IdEm int,
NombreE   varchar(30),
AppPatE   varchar(30),
AppMatE   varchar(30),
Email     varchar(30),
Telefono  varchar(10),
Estado    varchar(15),
Municipio varchar(15),
Colinioa  varchar(15),
Calle     varchar(15),
NUmI      varchar(15),
NumExt    varchar(15),
codig_postal varchar(15),
primary key (IdEm));

CREATE TABLE Factura(
idF int,
Fecha date,
idC int,
Estado boolean,
primary key (idF),
foreign key (idC) references Cliente(idC));

CREATE Table Proveedor(
idPro int,
nombre varchar(30),
ApPat  varchar(30),
ApMat  varchar(30),
telefono varchar(30),
Estado boolean,
primary key (idPro));

CREATE Table Cliente(
idC int,
nombre varchar (30),
AppPatE   varchar(30),
AppMatE   varchar(30),
Estados varchar(15),
Municipio varchar(15),
Colinioa varchar(15),
Calle  varchar(15),
NUmI varchar(15),
NumExt varchar(15),
codig_postal varchar(15),
telefono varchar (30),
primary key (idC));

CREATE TABLE Producto (
IdP int,
des varchar (30),
Precio double,
idC int,
idPro int,
Estado boolean,
primary key (IdP),
foreign key (idC) references CLiente (idC),
foreign key (idPro) references Proveedor(idPro));


CREATE TABLE VENTAS (
idV int,
idF int,
Estado boolean,
Total double,
primary key (idV),
foreign key (idF) references Factura(idF));


CREATE TABLE DetalleVentas(
folio int,
Conse int,
IdEm int,
idP int,
idC int,
cantidad int,
Estado boolean,
subTotal double,
primary key (folio,Conse),
foreign key (IdP) references Producto  (IdP),
foreign key (folio) references VENTAS (idV),
foreign key (IdEm) references Empleado (IdEm),
foreign key (idC) references Cliente (idC));





