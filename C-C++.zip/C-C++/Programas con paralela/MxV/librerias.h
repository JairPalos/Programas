#include <iostream>
#include <omp.h>
float* crea_vect(int);
//void ini_vect(float* ,int);
float* lee_vect(char *,int);
void muestra_vect(float* ,int);
void lee_datos(char *,char *,int,int);
void VxV(int);
