<?php
	
	include ("Conexion.php");
?>
<form action="" method="post">
	Folio: <input required name="folio"><br />
	Consecion: <input name="Conse"><br />
	ID_Proveedor: <input name="idP"><br />
	ID_Cliente: <input name="idC"><br />
	Cantdad: <input name="cantidad"><br />
	Subtotal: <input name="subtotal"><br />
	Estado:<br/>
	SI<input  value="si" type="radio" name="Estado"/>	
	NO<input  value="no" type="radio" name="Estado"/>
	<input type="submit"/>
</form>


<?php 
	if($_POST){

		$f=isset($_POST['folio']);
		$c=isset($_POST['Conse']);
		$ip=isset($_POST['idP']);
		$ic=isset($_POST['idC']);
		$can=isset($_POST['cantidad']);
		$sub=isset($_POST['subtotal']);
		$e=isset($_POST['Estado']);
	
		$sql= "INSERT INTO DetalleVentas(folio,Conse,idP,idC,cantidad,subtotal,Estado)values('$f','$c','$ip','$ic','$can','$sub','$e')";
		$resultado=$mysqli ->query($sql);
		echo "<h2> Dato Guardado </h2>";
		}
?>